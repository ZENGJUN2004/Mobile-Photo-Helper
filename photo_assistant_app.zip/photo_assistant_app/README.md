# 🎯 拍照助手 - Flutter跨平台APP

专注于测光和角度指导的智能拍照辅助应用，支持iOS、Android和鸿蒙系统。

## ✨ 核心功能

### 📸 智能测光
- 实时分析画面曝光值和亮度分布
- 检测过曝/欠曝区域
- 提供智能拍摄建议
- 显示亮度直方图

### 👤 角度指导  
- 实时面部检测和角度分析
- 支持正面、左侧、右侧拍摄模式
- 头部姿态实时指导
- 最佳角度提醒

### 🎨 用户界面
- 现代化暗色主题设计
- 实时信息覆盖层
- 直观的角度调整指示
- 简洁的相机控制界面

## 🛠 技术架构

### 核心技术栈
- **框架**: Flutter 3.0+
- **相机**: CameraAwesome 2.0+
- **图像处理**: OpenCV Dart 1.0+
- **面部检测**: Google ML Kit
- **状态管理**: Provider
- **权限管理**: Permission Handler

### 架构设计
- **Provider模式**: 响应式状态管理
- **Isolate并发**: 避免UI阻塞的图像处理
- **Platform Channel**: 鸿蒙系统原生集成
- **模块化设计**: 清晰的代码结构

## 🚀 快速开始

### 环境要求
- Flutter SDK 3.0+
- Dart SDK 3.0+
- Android Studio / Xcode
- 支持的设备: Android 5.0+ / iOS 11+ / 鸿蒙2.0+

### 安装和运行

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd photo_assistant_app
   ```

2. **安装依赖**
   ```bash
   flutter pub get
   ```

3. **运行项目**
   ```bash
   # Android
   flutter run
   
   # iOS (需要macOS)
   flutter run -d ios
   ```

4. **编译发布版本**
   ```bash
   # Android APK
   flutter build apk --release
   
   # iOS (需要Xcode)
   flutter build ios --release
   ```

### 快速测试
运行自动化测试脚本：
```bash
bash test_build.sh
```

## 📱 平台支持

### Android
- **最低版本**: Android 5.0 (API 21)
- **权限**: 相机、麦克风、存储
- **发布**: Google Play Store
- **测试**: 真机/模拟器

### iOS  
- **最低版本**: iOS 11.0
- **权限**: 相机、麦克风、照片库
- **发布**: App Store
- **测试**: 真机/模拟器

### 鸿蒙
- **最低版本**: HarmonyOS 2.0
- **集成方式**: Platform Channel + Camera Kit
- **发布**: 华为AppGallery
- **状态**: 适配代码已完成

## 📊 项目结构

```
lib/
├── main.dart                    # 应用入口
├── src/
│   ├── app.dart                # 应用配置
│   ├── screens/                # 页面
│   │   ├── home_screen.dart    # 主页
│   │   ├── camera_screen.dart  # 相机页面
│   │   └── settings_screen.dart # 设置页面
│   ├── widgets/                # UI组件
│   │   ├── light_meter_overlay.dart    # 测光覆盖层
│   │   ├── face_angle_overlay.dart     # 角度指导覆盖层
│   │   └── camera_controls.dart       # 相机控制
│   ├── providers/              # 状态管理
│   │   ├── camera_provider.dart       # 相机状态
│   │   ├── light_meter_provider.dart  # 测光分析
│   │   └── face_angle_provider.dart   # 角度分析
│   ├── services/               # 服务层
│   │   └── permission_service.dart    # 权限管理
│   └── platform/               # 平台适配
│       └── harmony_camera_channel.dart # 鸿蒙相机
harmony/                        # 鸿蒙原生代码
android/                        # Android配置
ios/                           # iOS配置
```

## 🔧 开发指南

### 测光算法
位置: `lib/src/providers/light_meter_provider.dart`
- 使用Isolate进行并发处理
- 基于亮度直方图分析
- 实时检测过曝/欠曝区域

### 面部检测
位置: `lib/src/providers/face_angle_provider.dart`  
- Google ML Kit面部检测
- 欧拉角分析(headEulerAngleY/Z/X)
- 多种拍摄模式支持

### 性能优化
- 降低相机预览分辨率(720p/480p)
- 限制分析帧率(10fps)
- 直接使用YUV格式避免转换
- 及时释放图像内存

## 📖 完整文档

- [📋 部署指南](../deployment_guide.md) - 详细的构建和发布流程
- [🔬 技术研究报告](../reports/mobile_vision_research_report.md) - 技术选型依据
- [🧪 测试报告](../test_report.md) - 代码质量和功能测试

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 开启Pull Request

## 📄 许可证

该项目使用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🆘 常见问题

### Q: 相机权限被拒绝怎么办？
A: 检查AndroidManifest.xml和Info.plist中的权限配置，确保权限描述清楚。

### Q: 面部检测不工作？
A: 确保光线充足，面部清晰可见，检查ML Kit配置。

### Q: 性能较慢怎么优化？
A: 调整分析帧率，降低预览分辨率，检查Isolate是否正常工作。

### Q: 如何支持鸿蒙系统？
A: 按照部署指南中的鸿蒙适配步骤，使用Platform Channel集成Camera Kit。

## 📞 联系方式

- 开发者: MiniMax Agent
- 项目地址: [GitHub Repository]
- 技术支持: [Issues]

---

⭐ 如果这个项目对您有帮助，请给它一个星标！

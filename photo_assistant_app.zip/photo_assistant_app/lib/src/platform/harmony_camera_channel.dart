import 'dart:typed_data';
import 'package:flutter/services.dart';

/// 鸿蒙系统相机Platform Channel
class HarmonyCameraChannel {
  static const MethodChannel _methodChannel = MethodChannel('harmony_camera');
  static const EventChannel _eventChannel = EventChannel('harmony_camera_stream');
  
  static Stream<Map<String, dynamic>>? _cameraStream;
  
  /// 初始化鸿蒙相机
  static Future<bool> initialize() async {
    try {
      final result = await _methodChannel.invokeMethod('initialize');
      return result as bool;
    } catch (e) {
      print('鸿蒙相机初始化失败: $e');
      return false;
    }
  }
  
  /// 启动相机预览
  static Future<bool> startPreview() async {
    try {
      final result = await _methodChannel.invokeMethod('startPreview');
      return result as bool;
    } catch (e) {
      print('启动相机预览失败: $e');
      return false;
    }
  }
  
  /// 停止相机预览
  static Future<bool> stopPreview() async {
    try {
      final result = await _methodChannel.invokeMethod('stopPreview');
      return result as bool;
    } catch (e) {
      print('停止相机预览失败: $e');
      return false;
    }
  }
  
  /// 拍照
  static Future<String?> takePicture() async {
    try {
      final result = await _methodChannel.invokeMethod('takePicture');
      return result as String?;
    } catch (e) {
      print('拍照失败: $e');
      return null;
    }
  }
  
  /// 切换摄像头
  static Future<bool> switchCamera() async {
    try {
      final result = await _methodChannel.invokeMethod('switchCamera');
      return result as bool;
    } catch (e) {
      print('切换摄像头失败: $e');
      return false;
    }
  }
  
  /// 设置分辨率
  static Future<bool> setResolution(int width, int height) async {
    try {
      final result = await _methodChannel.invokeMethod('setResolution', {
        'width': width,
        'height': height,
      });
      return result as bool;
    } catch (e) {
      print('设置分辨率失败: $e');
      return false;
    }
  }
  
  /// 获取相机帧流
  static Stream<Map<String, dynamic>> getCameraStream() {
    _cameraStream ??= _eventChannel.receiveBroadcastStream().map((dynamic event) {
      return Map<String, dynamic>.from(event);
    });
    return _cameraStream!;
  }
  
  /// 启动帧分析
  static Future<bool> startFrameAnalysis() async {
    try {
      final result = await _methodChannel.invokeMethod('startFrameAnalysis');
      return result as bool;
    } catch (e) {
      print('启动帧分析失败: $e');
      return false;
    }
  }
  
  /// 停止帧分析
  static Future<bool> stopFrameAnalysis() async {
    try {
      final result = await _methodChannel.invokeMethod('stopFrameAnalysis');
      return result as bool;
    } catch (e) {
      print('停止帧分析失败: $e');
      return false;
    }
  }
  
  /// 请求相机权限
  static Future<bool> requestCameraPermission() async {
    try {
      final result = await _methodChannel.invokeMethod('requestPermission');
      return result as bool;
    } catch (e) {
      print('请求相机权限失败: $e');
      return false;
    }
  }
  
  /// 释放相机资源
  static Future<void> dispose() async {
    try {
      await _methodChannel.invokeMethod('dispose');
    } catch (e) {
      print('释放相机资源失败: $e');
    }
  }
}

/// 鸿蒙相机帧数据
class HarmonyCameraFrame {
  final Uint8List imageData;
  final int width;
  final int height;
  final int format;
  final int timestamp;
  
  HarmonyCameraFrame({
    required this.imageData,
    required this.width,
    required this.height,
    required this.format,
    required this.timestamp,
  });
  
  factory HarmonyCameraFrame.fromMap(Map<String, dynamic> map) {
    return HarmonyCameraFrame(
      imageData: map['imageData'] as Uint8List,
      width: map['width'] as int,
      height: map['height'] as int,
      format: map['format'] as int,
      timestamp: map['timestamp'] as int,
    );
  }
}

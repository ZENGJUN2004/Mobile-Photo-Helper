import 'dart:typed_data';
import 'dart:isolate';
import 'package:flutter/foundation.dart';

class LightMeterData {
  final double averageBrightness;
  final double contrast;
  final bool isOverexposed;
  final bool isUnderexposed;
  final List<int> histogram;
  final String suggestion;
  
  LightMeterData({
    required this.averageBrightness,
    required this.contrast,
    required this.isOverexposed,
    required this.isUnderexposed,
    required this.histogram,
    required this.suggestion,
  });
}

class LightMeterProvider extends ChangeNotifier {
  LightMeterData? _currentData;
  bool _isAnalyzing = false;
  Isolate? _analysisIsolate;
  SendPort? _sendPort;
  ReceivePort? _receivePort;
  
  // Getters
  LightMeterData? get currentData => _currentData;
  bool get isAnalyzing => _isAnalyzing;
  
  /// 开始测光分析
  Future<void> startAnalysis() async {
    if (_isAnalyzing) return;
    
    try {
      _receivePort = ReceivePort();
      _analysisIsolate = await Isolate.spawn(
        _lightMeterIsolateEntry,
        _receivePort!.sendPort,
      );
      
      // 监听来自Isolate的消息
      _receivePort!.listen((message) {
        if (message is SendPort) {
          _sendPort = message;
        } else if (message is LightMeterData) {
          _currentData = message;
          notifyListeners();
        }
      });
      
      _isAnalyzing = true;
      notifyListeners();
    } catch (e) {
      debugPrint('启动测光分析失败: $e');
    }
  }
  
  /// 停止测光分析
  void stopAnalysis() {
    _analysisIsolate?.kill();
    _receivePort?.close();
    _analysisIsolate = null;
    _sendPort = null;
    _receivePort = null;
    _isAnalyzing = false;
    notifyListeners();
  }
  
  /// 处理图像帧
  void processFrame(Uint8List imageData, int width, int height) {
    if (_sendPort != null && _isAnalyzing) {
      _sendPort!.send({
        'imageData': imageData,
        'width': width,
        'height': height,
      });
    }
  }
  
  @override
  void dispose() {
    stopAnalysis();
    super.dispose();
  }
}

/// Isolate入口函数，用于处理测光分析
void _lightMeterIsolateEntry(SendPort sendPort) {
  final receivePort = ReceivePort();
  sendPort.send(receivePort.sendPort);
  
  receivePort.listen((message) {
    if (message is Map<String, dynamic>) {
      final imageData = message['imageData'] as Uint8List;
      final width = message['width'] as int;
      final height = message['height'] as int;
      
      // 执行测光分析
      final result = _analyzeLightMeter(imageData, width, height);
      sendPort.send(result);
    }
  });
}

/// 测光分析核心算法
LightMeterData _analyzeLightMeter(Uint8List imageData, int width, int height) {
  // 这里实现测光算法
  // 为了演示，使用简化版本
  
  // 计算亮度直方图
  final histogram = List<int>.filled(256, 0);
  int totalPixels = width * height;
  int brightnessSum = 0;
  
  // 假设图像是YUV格式，提取Y通道
  for (int i = 0; i < totalPixels && i < imageData.length; i++) {
    int brightness = imageData[i];
    histogram[brightness]++;
    brightnessSum += brightness;
  }
  
  // 计算平均亮度
  double averageBrightness = brightnessSum / totalPixels;
  
  // 计算对比度（简化算法）
  double variance = 0;
  for (int i = 0; i < totalPixels && i < imageData.length; i++) {
    double diff = imageData[i] - averageBrightness;
    variance += diff * diff;
  }
  double contrast = variance / totalPixels;
  
  // 检测过曝和欠曝
  int overexposedPixels = 0;
  int underexposedPixels = 0;
  
  for (int i = 250; i < 256; i++) {
    overexposedPixels += histogram[i];
  }
  for (int i = 0; i < 6; i++) {
    underexposedPixels += histogram[i];
  }
  
  bool isOverexposed = overexposedPixels > totalPixels * 0.05; // 5%阈值
  bool isUnderexposed = underexposedPixels > totalPixels * 0.05;
  
  // 生成建议
  String suggestion = _generateSuggestion(
    averageBrightness,
    isOverexposed,
    isUnderexposed,
    contrast,
  );
  
  return LightMeterData(
    averageBrightness: averageBrightness,
    contrast: contrast,
    isOverexposed: isOverexposed,
    isUnderexposed: isUnderexposed,
    histogram: histogram,
    suggestion: suggestion,
  );
}

/// 生成拍摄建议
String _generateSuggestion(
  double averageBrightness,
  bool isOverexposed,
  bool isUnderexposed,
  double contrast,
) {
  if (isOverexposed && isUnderexposed) {
    return '画面对比度过高，请调整光照条件';
  } else if (isOverexposed) {
    return '画面过曝，请降低曝光或避开强光';
  } else if (isUnderexposed) {
    return '画面偏暗，请增加光照或提高曝光';
  } else if (averageBrightness < 80) {
    return '光线偏暗，建议增加光源';
  } else if (averageBrightness > 180) {
    return '光线过亮，建议调整角度';
  } else if (contrast < 1000) {
    return '对比度较低，尝试改变拍摄角度';
  } else {
    return '光照条件良好，可以拍摄';
  }
}

import 'dart:typed_data';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

class FaceAngleData {
  final bool faceDetected;
  final double? headEulerAngleY; // 左右转头角度
  final double? headEulerAngleZ; // 歪头角度
  final double? headEulerAngleX; // 抬头低头角度
  final String suggestion;
  final bool isOptimalAngle;
  
  FaceAngleData({
    required this.faceDetected,
    this.headEulerAngleY,
    this.headEulerAngleZ,
    this.headEulerAngleX,
    required this.suggestion,
    required this.isOptimalAngle,
  });
}

class FaceAngleProvider extends ChangeNotifier {
  FaceAngleData? _currentData;
  bool _isAnalyzing = false;
  FaceDetector? _faceDetector;
  String _targetAngleMode = 'front'; // 'front', 'side_left', 'side_right'
  
  // Getters
  FaceAngleData? get currentData => _currentData;
  bool get isAnalyzing => _isAnalyzing;
  String get targetAngleMode => _targetAngleMode;
  
  /// 初始化面部检测器
  Future<void> initialize() async {
    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableClassification: false,
        enableLandmarks: false,
        enableContours: false,
        enableTracking: false,
        minFaceSize: 0.1,
        performanceMode: FaceDetectorMode.fast,
      ),
    );
  }
  
  /// 开始面部角度分析
  Future<void> startAnalysis() async {
    if (_isAnalyzing) return;
    
    await initialize();
    _isAnalyzing = true;
    notifyListeners();
  }
  
  /// 停止面部角度分析
  void stopAnalysis() {
    _faceDetector?.close();
    _faceDetector = null;
    _isAnalyzing = false;
    notifyListeners();
  }
  
  /// 设置目标角度模式
  void setTargetAngleMode(String mode) {
    _targetAngleMode = mode;
    notifyListeners();
  }
  
  /// 处理图像帧
  Future<void> processFrame(InputImage inputImage) async {
    if (!_isAnalyzing || _faceDetector == null) return;
    
    try {
      final faces = await _faceDetector!.processImage(inputImage);
      
      if (faces.isEmpty) {
        _currentData = FaceAngleData(
          faceDetected: false,
          suggestion: '请将面部对准相机',
          isOptimalAngle: false,
        );
      } else {
        final face = faces.first; // 使用第一个检测到的面部
        final angleData = _analyzeFaceAngle(face);
        _currentData = angleData;
      }
      
      notifyListeners();
    } catch (e) {
      debugPrint('面部检测失败: $e');
    }
  }
  
  /// 分析面部角度
  FaceAngleData _analyzeFaceAngle(Face face) {
    final headEulerAngleY = face.headEulerAngleY; // 左右转头
    final headEulerAngleZ = face.headEulerAngleZ; // 歪头
    final headEulerAngleX = face.headEulerAngleX; // 抬头低头
    
    // 根据目标角度模式生成建议
    final suggestion = _generateAngleSuggestion(
      headEulerAngleY,
      headEulerAngleZ,
      headEulerAngleX,
      _targetAngleMode,
    );
    
    // 判断是否为最佳角度
    final isOptimal = _isOptimalAngle(
      headEulerAngleY,
      headEulerAngleZ,
      headEulerAngleX,
      _targetAngleMode,
    );
    
    return FaceAngleData(
      faceDetected: true,
      headEulerAngleY: headEulerAngleY,
      headEulerAngleZ: headEulerAngleZ,
      headEulerAngleX: headEulerAngleX,
      suggestion: suggestion,
      isOptimalAngle: isOptimal,
    );
  }
  
  /// 生成角度调整建议
  String _generateAngleSuggestion(
    double? angleY,
    double? angleZ,
    double? angleX,
    String mode,
  ) {
    if (angleY == null || angleZ == null || angleX == null) {
      return '请保持面部清晰可见';
    }
    
    List<String> suggestions = [];
    
    // 检查歪头角度（Z轴）
    if (angleZ.abs() > 8) {
      if (angleZ > 0) {
        suggestions.add('请将头部向左摆正');
      } else {
        suggestions.add('请将头部向右摆正');
      }
    }
    
    // 检查抬头低头角度（X轴）
    if (angleX.abs() > 15) {
      if (angleX > 0) {
        suggestions.add('请稍微低头');
      } else {
        suggestions.add('请稍微抬头');
      }
    }
    
    // 根据目标模式检查左右转头角度（Y轴）
    switch (mode) {
      case 'front':
        if (angleY.abs() > 10) {
          if (angleY > 0) {
            suggestions.add('请向左转头面向相机');
          } else {
            suggestions.add('请向右转头面向相机');
          }
        }
        break;
      case 'side_left':
        double targetAngle = 45;
        if ((angleY - targetAngle).abs() > 10) {
          if (angleY < targetAngle - 10) {
            suggestions.add('请继续向右转头');
          } else if (angleY > targetAngle + 10) {
            suggestions.add('请稍微向左转头');
          }
        }
        break;
      case 'side_right':
        double targetAngle = -45;
        if ((angleY - targetAngle).abs() > 10) {
          if (angleY > targetAngle + 10) {
            suggestions.add('请继续向左转头');
          } else if (angleY < targetAngle - 10) {
            suggestions.add('请稍微向右转头');
          }
        }
        break;
    }
    
    if (suggestions.isEmpty) {
      return '角度很好，可以拍摄了！';
    } else {
      return suggestions.join('，');
    }
  }
  
  /// 判断是否为最佳角度
  bool _isOptimalAngle(
    double? angleY,
    double? angleZ,
    double? angleX,
    String mode,
  ) {
    if (angleY == null || angleZ == null || angleX == null) {
      return false;
    }
    
    // 检查基本条件
    bool zGood = angleZ.abs() <= 8; // 头部摆正
    bool xGood = angleX.abs() <= 15; // 不过度抬头或低头
    
    bool yGood = false;
    switch (mode) {
      case 'front':
        yGood = angleY.abs() <= 10; // 正面朝向
        break;
      case 'side_left':
        yGood = (angleY - 45).abs() <= 10; // 左侧45度
        break;
      case 'side_right':
        yGood = (angleY + 45).abs() <= 10; // 右侧45度
        break;
    }
    
    return zGood && xGood && yGood;
  }
  
  @override
  void dispose() {
    stopAnalysis();
    super.dispose();
  }
}

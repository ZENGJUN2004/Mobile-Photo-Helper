import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:camerawesome/camerawesome_plugin.dart';

class CameraProvider extends ChangeNotifier {
  bool _isInitialized = false;
  bool _isAnalyzing = false;
  bool _lightMeterEnabled = true;
  bool _faceAngleEnabled = true;
  CameraController? _controller;
  
  // Getters
  bool get isInitialized => _isInitialized;
  bool get isAnalyzing => _isAnalyzing;
  bool get lightMeterEnabled => _lightMeterEnabled;
  bool get faceAngleEnabled => _faceAngleEnabled;
  CameraController? get controller => _controller;
  
  /// 初始化相机
  Future<void> initializeCamera() async {
    try {
      _isInitialized = true;
      notifyListeners();
    } catch (e) {
      debugPrint('相机初始化失败: $e');
      _isInitialized = false;
      notifyListeners();
    }
  }
  
  /// 设置相机控制器
  void setCameraController(CameraController controller) {
    _controller = controller;
    notifyListeners();
  }
  
  /// 开始图像分析
  void startAnalysis() {
    _isAnalyzing = true;
    notifyListeners();
  }
  
  /// 停止图像分析
  void stopAnalysis() {
    _isAnalyzing = false;
    notifyListeners();
  }
  
  /// 切换测光功能
  void toggleLightMeter() {
    _lightMeterEnabled = !_lightMeterEnabled;
    notifyListeners();
  }
  
  /// 切换角度指导功能
  void toggleFaceAngle() {
    _faceAngleEnabled = !_faceAngleEnabled;
    notifyListeners();
  }
  
  /// 处理图像帧
  void processImageFrame(Uint8List imageData) {
    if (!_isAnalyzing) return;
    
    // 在这里处理图像帧，传递给测光和面部识别服务
    // 实际处理会在Isolate中进行
  }
  
  /// 释放资源
  void dispose() {
    _controller = null;
    _isInitialized = false;
    _isAnalyzing = false;
    super.dispose();
  }
}

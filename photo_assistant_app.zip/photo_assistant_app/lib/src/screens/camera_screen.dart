import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:camerawesome/camerawesome_plugin.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import '../providers/camera_provider.dart';
import '../providers/light_meter_provider.dart';
import '../providers/face_angle_provider.dart';
import '../widgets/light_meter_overlay.dart';
import '../widgets/face_angle_overlay.dart';
import '../widgets/camera_controls.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeProviders();
    });
  }

  void _initializeProviders() {
    final cameraProvider = context.read<CameraProvider>();
    final lightMeterProvider = context.read<LightMeterProvider>();
    final faceAngleProvider = context.read<FaceAngleProvider>();

    cameraProvider.initializeCamera();
    lightMeterProvider.startAnalysis();
    faceAngleProvider.startAnalysis();
  }

  @override
  void dispose() {
    final lightMeterProvider = context.read<LightMeterProvider>();
    final faceAngleProvider = context.read<FaceAngleProvider>();
    
    lightMeterProvider.stopAnalysis();
    faceAngleProvider.stopAnalysis();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Consumer<CameraProvider>(
        builder: (context, cameraProvider, child) {
          if (!cameraProvider.isInitialized) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          return Stack(
            children: [
              // 相机预览
              _buildCameraPreview(),
              
              // 测光覆盖层
              if (cameraProvider.lightMeterEnabled)
                const LightMeterOverlay(),
              
              // 面部角度覆盖层
              if (cameraProvider.faceAngleEnabled)
                const FaceAngleOverlay(),
              
              // 顶部控制栏
              _buildTopControls(),
              
              // 底部控制栏
              const Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: CameraControls(),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildCameraPreview() {
    return CameraAwesomeBuilder.awesome(
      saveConfig: SaveConfig.photo(
        pathBuilder: () async {
          final DateTime now = DateTime.now();
          final String timestamp = now.millisecondsSinceEpoch.toString();
          return '/storage/emulated/0/DCIM/Camera/photo_assistant_$timestamp.jpg';
        },
      ),
      sensorConfig: SensorConfig.single(
        sensor: Sensor.position(SensorPosition.back),
        aspectRatio: CameraAspectRatios.ratio_16_9,
        zoom: 0.0,
      ),
      enablePhysicalButton: true,
      filter: AwesomeFilter.None,
      onMediaTap: (mediaCapture) {
        // 处理媒体点击事件
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('照片已保存: ${mediaCapture.captureRequest.when(
              single: (single) => single.file?.path ?? '未知路径',
            )}'),
            duration: const Duration(seconds: 2),
          ),
        );
      },
      onImageForAnalysis: (AnalysisImage img) {
        // 处理实时图像分析
        _processImageForAnalysis(img);
      },
      imageAnalysisConfig: AnalysisConfig(
        androidOptions: const AndroidAnalysisOptions.nv21(
          width: 1024,
        ),
        maxFramesPerSecond: 10, // 限制帧率以提高性能
      ),
    );
  }

  Widget _buildTopControls() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.6),
                Colors.transparent,
              ],
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // 返回按钮
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              
              // 功能切换按钮
              Row(
                children: [
                  Consumer<CameraProvider>(
                    builder: (context, provider, child) {
                      return IconButton(
                        onPressed: provider.toggleLightMeter,
                        icon: Icon(
                          Icons.lightbulb,
                          color: provider.lightMeterEnabled 
                              ? Colors.orange 
                              : Colors.white54,
                          size: 24,
                        ),
                      );
                    },
                  ),
                  Consumer<CameraProvider>(
                    builder: (context, provider, child) {
                      return IconButton(
                        onPressed: provider.toggleFaceAngle,
                        icon: Icon(
                          Icons.face,
                          color: provider.faceAngleEnabled 
                              ? Colors.green 
                              : Colors.white54,
                          size: 24,
                        ),
                      );
                    },
                  ),
                ],
              ),
              
              // 设置按钮
              IconButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/settings');
                },
                icon: const Icon(
                  Icons.settings,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _processImageForAnalysis(AnalysisImage analysisImage) {
    final cameraProvider = context.read<CameraProvider>();
    final lightMeterProvider = context.read<LightMeterProvider>();
    final faceAngleProvider = context.read<FaceAngleProvider>();

    // 处理测光分析
    if (cameraProvider.lightMeterEnabled) {
      lightMeterProvider.processFrame(
        analysisImage.nv21Image,
        analysisImage.width,
        analysisImage.height,
      );
    }

    // 处理面部角度分析
    if (cameraProvider.faceAngleEnabled) {
      final inputImage = InputImage.fromBytes(
        bytes: analysisImage.nv21Image,
        metadata: InputImageMetadata(
          size: Size(analysisImage.width.toDouble(), analysisImage.height.toDouble()),
          rotation: InputImageRotation.rotation0deg,
          format: InputImageFormat.nv21,
          bytesPerRow: analysisImage.width,
        ),
      );
      
      faceAngleProvider.processFrame(inputImage);
    }
  }
}

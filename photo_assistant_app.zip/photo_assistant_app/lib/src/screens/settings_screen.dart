import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/face_angle_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // 拍摄模式设置
          _buildSectionHeader('拍摄模式'),
          _buildAngleModeSettings(),
          
          const SizedBox(height: 24),
          
          // 分析设置
          _buildSectionHeader('分析设置'),
          _buildAnalysisSettings(),
          
          const SizedBox(height: 24),
          
          // 关于应用
          _buildSectionHeader('关于'),
          _buildAboutSection(),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildAngleModeSettings() {
    return Consumer<FaceAngleProvider>(
      builder: (context, provider, child) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
            ),
          ),
          child: Column(
            children: [
              _buildSettingItem(
                title: '正面拍摄',
                subtitle: '适合证件照、自拍等',
                trailing: Radio<String>(
                  value: 'front',
                  groupValue: provider.targetAngleMode,
                  onChanged: (value) {
                    if (value != null) {
                      provider.setTargetAngleMode(value);
                    }
                  },
                  activeColor: Colors.blue,
                ),
              ),
              _buildDivider(),
              _buildSettingItem(
                title: '左侧45度',
                subtitle: '突出脸部轮廓，适合人像摄影',
                trailing: Radio<String>(
                  value: 'side_left',
                  groupValue: provider.targetAngleMode,
                  onChanged: (value) {
                    if (value != null) {
                      provider.setTargetAngleMode(value);
                    }
                  },
                  activeColor: Colors.blue,
                ),
              ),
              _buildDivider(),
              _buildSettingItem(
                title: '右侧45度',
                subtitle: '突出脸部轮廓，适合人像摄影',
                trailing: Radio<String>(
                  value: 'side_right',
                  groupValue: provider.targetAngleMode,
                  onChanged: (value) {
                    if (value != null) {
                      provider.setTargetAngleMode(value);
                    }
                  },
                  activeColor: Colors.blue,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAnalysisSettings() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
        ),
      ),
      child: Column(
        children: [
          _buildSettingItem(
            title: '实时测光',
            subtitle: '分析画面曝光和亮度分布',
            trailing: Switch(
              value: true, // 这里应该从状态管理获取
              onChanged: (value) {
                // 切换测光功能
              },
              activeColor: Colors.blue,
            ),
          ),
          _buildDivider(),
          _buildSettingItem(
            title: '面部角度指导',
            subtitle: '检测面部角度并提供调整建议',
            trailing: Switch(
              value: true, // 这里应该从状态管理获取
              onChanged: (value) {
                // 切换角度指导功能
              },
              activeColor: Colors.blue,
            ),
          ),
          _buildDivider(),
          _buildSettingItem(
            title: '语音提示',
            subtitle: '播放角度调整的语音指导',
            trailing: Switch(
              value: false, // 这里应该从状态管理获取
              onChanged: (value) {
                // 切换语音提示功能
              },
              activeColor: Colors.blue,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutSection() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
        ),
      ),
      child: Column(
        children: [
          _buildSettingItem(
            title: '版本',
            subtitle: '1.0.0',
            trailing: const Icon(
              Icons.info_outline,
              color: Colors.white54,
            ),
          ),
          _buildDivider(),
          _buildSettingItem(
            title: '帮助与反馈',
            subtitle: '使用说明和问题反馈',
            trailing: const Icon(
              Icons.help_outline,
              color: Colors.white54,
            ),
            onTap: () {
              // 显示帮助信息
              _showHelpDialog(context);
            },
          ),
          _buildDivider(),
          _buildSettingItem(
            title: '隐私政策',
            subtitle: '查看应用隐私政策',
            trailing: const Icon(
              Icons.privacy_tip_outlined,
              color: Colors.white54,
            ),
            onTap: () {
              // 显示隐私政策
              _showPrivacyDialog(context);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSettingItem({
    required String title,
    required String subtitle,
    required Widget trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      title: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(
          color: Colors.white54,
          fontSize: 14,
        ),
      ),
      trailing: trailing,
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 1,
      color: Colors.white.withOpacity(0.1),
      indent: 16,
      endIndent: 16,
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          '使用帮助',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          '1. 打开相机后，应用会自动进行测光分析\n'
          '2. 当检测到面部时，会提供角度调整建议\n'
          '3. 绿色提示表示当前条件良好\n'
          '4. 橙色或红色提示需要调整\n'
          '5. 可在设置中切换不同的拍摄模式',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }

  void _showPrivacyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          '隐私政策',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          '本应用仅在本地处理图像数据，不会上传任何照片或个人信息到服务器。\n\n'
          '相机权限仅用于拍照和实时分析功能。\n\n'
          '所有分析处理均在设备本地完成，保护您的隐私安全。',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}

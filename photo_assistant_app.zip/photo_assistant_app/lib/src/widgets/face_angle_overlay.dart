import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/face_angle_provider.dart';

class FaceAngleOverlay extends StatelessWidget {
  const FaceAngleOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<FaceAngleProvider>(
      builder: (context, provider, child) {
        if (!provider.isAnalyzing || provider.currentData == null) {
          return const SizedBox.shrink();
        }

        final data = provider.currentData!;
        
        return Positioned(
          bottom: 180,
          left: 16,
          right: 16,
          child: Column(
            children: [
              // 面部检测状态
              if (!data.faceDetected)
                _buildNoFaceDetectedCard()
              else ...[
                // 角度指导卡片
                _buildAngleGuideCard(data),
                
                const SizedBox(height: 12),
                
                // 角度详情
                _buildAngleDetailsCard(data),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildNoFaceDetectedCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.orange.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.face,
            color: Colors.orange,
            size: 24,
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              '请将面部对准相机',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAngleGuideCard(FaceAngleData data) {
    Color statusColor = data.isOptimalAngle ? Colors.green : Colors.orange;
    IconData statusIcon = data.isOptimalAngle ? Icons.check_circle : Icons.adjust;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: statusColor.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: Column(
        children: [
          // 状态指示器
          Row(
            children: [
              Icon(
                statusIcon,
                color: statusColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              const Text(
                '角度指导',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  data.isOptimalAngle ? '最佳角度' : '需要调整',
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // 建议
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                // 指示箭头或图标
                _buildDirectionIndicator(data),
                
                const SizedBox(width: 12),
                
                // 建议文本
                Expanded(
                  child: Text(
                    data.suggestion,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAngleDetailsCard(FaceAngleData data) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '角度详情',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              if (data.headEulerAngleY != null)
                Expanded(
                  child: _buildAngleItem(
                    '左右转头',
                    data.headEulerAngleY!,
                    Colors.blue,
                    Icons.rotate_90_degrees_ccw,
                  ),
                ),
              if (data.headEulerAngleZ != null)
                Expanded(
                  child: _buildAngleItem(
                    '歪头',
                    data.headEulerAngleZ!,
                    Colors.purple,
                    Icons.screen_rotation,
                  ),
                ),
              if (data.headEulerAngleX != null)
                Expanded(
                  child: _buildAngleItem(
                    '抬头低头',
                    data.headEulerAngleX!,
                    Colors.green,
                    Icons.unfold_more,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAngleItem(String label, double angle, Color color, IconData icon) {
    return Column(
      children: [
        Icon(
          icon,
          color: color,
          size: 16,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 10,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          '${angle.toStringAsFixed(1)}°',
          style: TextStyle(
            color: color,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildDirectionIndicator(FaceAngleData data) {
    // 根据建议内容显示方向指示
    String suggestion = data.suggestion.toLowerCase();
    
    if (data.isOptimalAngle) {
      return Icon(
        Icons.check_circle,
        color: Colors.green,
        size: 20,
      );
    }
    
    if (suggestion.contains('向左转')) {
      return Icon(
        Icons.arrow_back,
        color: Colors.orange,
        size: 20,
      );
    } else if (suggestion.contains('向右转')) {
      return Icon(
        Icons.arrow_forward,
        color: Colors.orange,
        size: 20,
      );
    } else if (suggestion.contains('抬头')) {
      return Icon(
        Icons.keyboard_arrow_up,
        color: Colors.orange,
        size: 20,
      );
    } else if (suggestion.contains('低头')) {
      return Icon(
        Icons.keyboard_arrow_down,
        color: Colors.orange,
        size: 20,
      );
    } else if (suggestion.contains('摆正')) {
      return Icon(
        Icons.straighten,
        color: Colors.orange,
        size: 20,
      );
    } else {
      return Icon(
        Icons.face,
        color: Colors.orange,
        size: 20,
      );
    }
  }
}

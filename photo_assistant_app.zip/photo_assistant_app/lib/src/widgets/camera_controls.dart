import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/face_angle_provider.dart';
import '../providers/light_meter_provider.dart';

class CameraControls extends StatelessWidget {
  const CameraControls({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [
              Colors.black.withOpacity(0.8),
              Colors.transparent,
            ],
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 快速模式切换
            _buildQuickModeSwitch(),
            
            const SizedBox(height: 16),
            
            // 主要控制按钮
            _buildMainControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickModeSwitch() {
    return Consumer<FaceAngleProvider>(
      builder: (context, provider, child) {
        return Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildModeButton(
                context,
                '正面',
                'front',
                provider.targetAngleMode == 'front',
                () => provider.setTargetAngleMode('front'),
              ),
              _buildModeButton(
                context,
                '左侧',
                'side_left',
                provider.targetAngleMode == 'side_left',
                () => provider.setTargetAngleMode('side_left'),
              ),
              _buildModeButton(
                context,
                '右侧',
                'side_right',
                provider.targetAngleMode == 'side_right',
                () => provider.setTargetAngleMode('side_right'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildModeButton(
    BuildContext context,
    String label,
    String mode,
    bool isSelected,
    VoidCallback onPressed,
  ) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildMainControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // 图库按钮
        _buildControlButton(
          icon: Icons.photo_library,
          onPressed: () {
            // 打开图库功能
          },
        ),
        
        // 拍照按钮
        _buildShutterButton(),
        
        // 切换摄像头按钮
        _buildControlButton(
          icon: Icons.flip_camera_ios,
          onPressed: () {
            // 切换前后摄像头
          },
        ),
      ],
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withOpacity(0.5),
        border: Border.all(
          color: Colors.white.withOpacity(0.3),
          width: 2,
        ),
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(
          icon,
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }

  Widget _buildShutterButton() {
    return Consumer2<FaceAngleProvider, LightMeterProvider>(
      builder: (context, faceProvider, lightProvider, child) {
        // 根据当前状态决定按钮颜色
        bool isOptimal = faceProvider.currentData?.isOptimalAngle ?? false;
        Color buttonColor = isOptimal ? Colors.green : Colors.white;
        
        return GestureDetector(
          onTap: () {
            // 拍照功能
            _takePicture(context);
          },
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.5),
              border: Border.all(
                color: buttonColor,
                width: 4,
              ),
            ),
            child: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: buttonColor,
              ),
              child: Icon(
                Icons.camera_alt,
                color: Colors.black,
                size: 32,
              ),
            ),
          ),
        );
      },
    );
  }

  void _takePicture(BuildContext context) {
    // 这里实现拍照功能
    // 由于使用了CameraAwesome，拍照功能应该通过其API实现
    
    // 显示拍照反馈
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('拍照成功！'),
        duration: Duration(seconds: 1),
        backgroundColor: Colors.green,
      ),
    );
    
    // 可以添加拍照音效或震动反馈
    // HapticFeedback.mediumImpact();
  }
}

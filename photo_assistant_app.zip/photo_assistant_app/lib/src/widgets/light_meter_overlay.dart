import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/light_meter_provider.dart';

class LightMeterOverlay extends StatelessWidget {
  const LightMeterOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<LightMeterProvider>(
      builder: (context, provider, child) {
        if (!provider.isAnalyzing || provider.currentData == null) {
          return const SizedBox.shrink();
        }

        final data = provider.currentData!;
        
        return Positioned(
          top: 100,
          left: 16,
          right: 16,
          child: Column(
            children: [
              // 测光信息卡片
              _buildLightMeterCard(data),
              
              const SizedBox(height: 16),
              
              // 直方图显示
              _buildHistogramCard(data),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLightMeterCard(LightMeterData data) {
    Color statusColor = _getStatusColor(data);
    IconData statusIcon = _getStatusIcon(data);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: statusColor.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 状态指示器
          Row(
            children: [
              Icon(
                statusIcon,
                color: statusColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              const Text(
                '测光分析',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _getStatusText(data),
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // 测光数据
          Row(
            children: [
              Expanded(
                child: _buildDataItem(
                  '平均亮度',
                  '${data.averageBrightness.toInt()}',
                  Colors.blue,
                ),
              ),
              Expanded(
                child: _buildDataItem(
                  '对比度',
                  '${(data.contrast / 1000).toStringAsFixed(1)}K',
                  Colors.purple,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // 建议
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              data.suggestion,
              style: TextStyle(
                color: statusColor,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistogramCard(LightMeterData data) {
    return Container(
      height: 80,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '亮度分布',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _buildHistogram(data.histogram),
          ),
        ],
      ),
    );
  }

  Widget _buildHistogram(List<int> histogram) {
    if (histogram.isEmpty) {
      return const Center(
        child: Text(
          '无数据',
          style: TextStyle(color: Colors.white54),
        ),
      );
    }

    int maxValue = histogram.reduce((a, b) => a > b ? a : b);
    if (maxValue == 0) maxValue = 1;

    return Row(
      children: List.generate(histogram.length, (index) {
        double height = (histogram[index] / maxValue) * 40;
        Color barColor = _getHistogramBarColor(index);
        
        return Expanded(
          child: Container(
            height: height,
            margin: const EdgeInsets.symmetric(horizontal: 0.2),
            decoration: BoxDecoration(
              color: barColor,
              borderRadius: BorderRadius.circular(1),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildDataItem(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(LightMeterData data) {
    if (data.isOverexposed || data.isUnderexposed) {
      return Colors.red;
    } else if (data.averageBrightness < 80 || data.averageBrightness > 180) {
      return Colors.orange;
    } else {
      return Colors.green;
    }
  }

  IconData _getStatusIcon(LightMeterData data) {
    if (data.isOverexposed) {
      return Icons.brightness_high;
    } else if (data.isUnderexposed) {
      return Icons.brightness_low;
    } else {
      return Icons.lightbulb;
    }
  }

  String _getStatusText(LightMeterData data) {
    if (data.isOverexposed && data.isUnderexposed) {
      return '对比过高';
    } else if (data.isOverexposed) {
      return '过曝';
    } else if (data.isUnderexposed) {
      return '欠曝';
    } else {
      return '良好';
    }
  }

  Color _getHistogramBarColor(int index) {
    if (index < 32) {
      return Colors.blue; // 暗部
    } else if (index < 224) {
      return Colors.green; // 中间调
    } else {
      return Colors.red; // 高光
    }
  }
}

#!/bin/bash

# Flutter拍照辅助APP编译测试脚本
# 用于快速验证项目是否可以正常编译

echo "🚀 Flutter拍照助手APP编译测试"
echo "================================"

# 检查Flutter是否安装
echo "📋 1. 检查Flutter环境..."
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter未安装或未添加到PATH中"
    echo "   请先安装Flutter: https://flutter.dev/docs/get-started/install"
    exit 1
else
    echo "✅ Flutter已安装"
    flutter --version
fi

# 检查当前目录
if [ ! -f "pubspec.yaml" ]; then
    echo "❌ 请在Flutter项目根目录中运行此脚本"
    exit 1
fi

echo ""
echo "📦 2. 获取依赖包..."
flutter pub get

if [ $? -ne 0 ]; then
    echo "❌ 依赖包获取失败"
    echo "   请检查网络连接和pubspec.yaml配置"
    exit 1
else
    echo "✅ 依赖包获取成功"
fi

echo ""
echo "🔍 3. 分析代码..."
flutter analyze

if [ $? -ne 0 ]; then
    echo "⚠️ 代码分析发现问题，但不影响编译"
else
    echo "✅ 代码分析通过"
fi

echo ""
echo "🔨 4. 尝试编译Android APK..."
flutter build apk --debug

if [ $? -ne 0 ]; then
    echo "❌ Android编译失败"
    echo "   常见问题:"
    echo "   - 检查Android SDK是否正确安装"
    echo "   - 检查Gradle配置"
    echo "   - 检查网络连接（下载依赖）"
    exit 1
else
    echo "✅ Android编译成功！"
    echo "   APK文件位置: build/app/outputs/flutter-apk/app-debug.apk"
fi

echo ""
echo "📱 5. 检查可用设备..."
flutter devices

echo ""
echo "🎉 编译测试完成！"
echo "================================"
echo "下一步操作建议:"
echo "1. 连接Android设备或启动模拟器"
echo "2. 运行: flutter run"
echo "3. 测试相机权限和核心功能"
echo ""
echo "如需编译iOS版本:"
echo "1. 在macOS上运行: flutter build ios"
echo "2. 使用Xcode打开ios/Runner.xcworkspace"
echo ""
echo "更多信息请查看: deployment_guide.md"

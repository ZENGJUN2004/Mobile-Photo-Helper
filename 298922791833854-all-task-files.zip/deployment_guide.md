# Flutter拍照辅助APP部署指南

**文档版本**: 1.0
**最后更新**: 2025年8月7日
**适用项目**: Photo Assistant App (位于 `/workspace/photo_assistant_app/`)

---

## 摘要

本指南为“Flutter拍照辅助APP”提供了全面的部署、发布和维护说明。应用核心功能包括实时测光和面部角度指导，支持Android、iOS和鸿蒙（HarmonyOS）三大平台。本文档旨在帮助开发者快速完成环境配置、项目构建、多平台发布、性能优化和后续维护工作。

本指南基于项目代码和[《移动端计算机视觉与相机处理技术方案研究报告》](/workspace/reports/mobile_vision_research_report.md)编写。

---

## 1. 开发环境配置

确保您的开发环境满足以下要求，以保证项目顺利编译和运行。

### 1.1. 核心SDK安装
- **Flutter SDK**:
  - **版本**: 3.10.x 或更高版本。
  - **配置**: 确保`flutter`命令行工具已加入系统环境变量中。运行 `flutter doctor` 检查环境配置是否完善。
- **Android Studio**:
  - **版本**: Electric Eel | 2022.1.1 或更高版本。
  - **配置**: 安装 Android SDK、命令行工具和 Android SDK Build-Tools。用于Android应用编译和调试。
- **Xcode**:
  - **版本**: 14.x 或更高版本。
  - **配置**: 安装 Xcode command-line tools。用于iOS应用编译、签名和发布。仅在macOS上可用。
- **鸿蒙DevEco Studio**:
  - **版本**: 3.1 Release 或更高版本。
  - **配置**: 安装鸿蒙SDK。用于鸿蒙原生模块的编译、调试和打包。

### 1.2. 关键插件与依赖
项目依赖的关键插件已在 `pubspec.yaml` 中定义。核心技术栈包括：
- `camerawesome`: 相机控制与预览。
- `google_ml_kit_face_detection`: 面部识别与姿态分析。
- `opencv_dart`: （通过FFI）用于高性能测光算法。
- `permission_handler`: 跨平台权限管理。
- `provider` / `flutter_bloc`: （根据项目实际情况选择）状态管理。

---

## 2. 项目构建步骤

### 2.1. 获取项目代码
```bash
git clone <your-repo-url> photo_assistant_app
cd photo_assistant_app
```

### 2.2. 安装依赖包
在项目根目录下运行，获取所有Dart和Flutter依赖：
```bash
flutter pub get
```

### 2.3. 平台特定配置

**Android & iOS**:
- **OpenCV 集成**: 需要在 `android/app` 和 `ios/` 目录下分别配置OpenCV原生库的依赖。请遵循 `opencv_dart` 插件的官方安装指南进行配置。
- **ML Kit**: 通常无需额外配置，插件会自动处理。

**鸿蒙 (HarmonyOS)**:
- 项目的鸿蒙原生部分位于 `harmony/` 目录下。需要在DevEco Studio中单独打开此目录进行配置和编译。

---

## 3. iOS部署指南

### 3.1. 证书和配置文件设置 (Signing & Capabilities)
1.  在Xcode中打开 `ios/Runner.xcworkspace`。
2.  在 **Runner > Targets > Signing & Capabilities** 中：
    - **Team**: 选择您的Apple开发者账户。
    - **Bundle Identifier**: 设置唯一的应用ID (例如 `com.yourcompany.photoassistant`)。
    - Xcode会自动处理或提示您创建相应的配置文件（Provisioning Profile）。

### 3.2. 权限配置
检查 `ios/Runner/Info.plist` 文件，确保包含以下相机和麦克风的使用描述：
```xml
<key>NSCameraUsageDescription</key>
<string>我们需要访问您的相机以提供实时测光和拍摄角度指导。</string>
<key>NSMicrophoneUsageDescription</key>
<string>我们需要访问您的麦克风以在录制视频时收录声音。</string>
```

### 3.3. App Store发布流程
1.  **构建归档 (Archive)**:
    ```bash
    flutter build ipa --release
    ```
    或者在Xcode中选择 **Product > Archive**。
2.  **上传至App Store Connect**:
    - 在Xcode的Organizer窗口中，选择刚创建的归档文件，点击 "Distribute App"。
    - 按照向导将应用上传至App Store Connect。
3.  **TestFlight测试**: 在App Store Connect中配置内部和外部测试，分发给测试人员进行测试。
4.  **提交审核**: 创建新的App版本，填写所有元数据（截图、描述、关键词等），然后提交给Apple审核。

---

## 4. Android部署指南

### 4.1. 应用签名配置
1.  **生成签名密钥 (Keystore)**: 如果您还没有签名密钥，请使用`keytool`生成：
    ```bash
    keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
    ```
2.  **配置签名信息**:
    - 在 `android/` 目录下创建 `key.properties` 文件 (并将其加入 `.gitignore`)，内容如下：
      ```properties
      storePassword=<您的密钥库密码>
      keyPassword=<您的密钥别名密码>
      keyAlias=my-key-alias
      storeFile=my-release-key.jks
      ```
    - 修改 `android/app/build.gradle` 文件，引用签名配置：
      ```groovy
      ...
      android {
          signingConfigs {
              release {
                  if (project.hasProperty('keyPassword')) {
                      storeFile file(project.property('storeFile'))
                      storePassword project.property('storePassword')
                      keyAlias project.property('keyAlias')
                      keyPassword project.property('keyPassword')
                  }
              }
          }
          buildTypes {
              release {
                  signingConfig signingConfigs.release
              }
          }
      }
      ```

### 4.2. 权限和功能配置
检查 `android/app/src/main/AndroidManifest.xml` 确保相机等权限已声明：
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

### 4.3. Google Play Store发布
1.  **构建App Bundle**:
    ```bash
    flutter build appbundle --release
    ```
    这将在 `build/app/outputs/bundle/release/` 目录下生成 `app-release.aab` 文件。
2.  **上传至Play Console**:
    - 登录您的Google Play Console。
    - 创建或选择您的应用。
    - 前往 **发布 > 正式版**，创建一个新版本。
    - 上传 `.aab` 文件，填写版本说明，然后发布。

### 4.4. APK直接安装方法
如需生成用于直接安装的APK文件，运行：
```bash
flutter build apk --release
```

---

## 5. 鸿蒙系统部署指南

鸿蒙平台的集成依赖 **Platform Channel**。Flutter端代码位于 `lib/platform/harmony_camera_channel.dart`，原生端代码位于 `harmony/` 目录。

### 5.1. DevEco Studio项目配置
1.  使用DevEco Studio打开项目根目录下的 `harmony` 文件夹。
2.  同步项目，DevEco Studio会自动下载所需的Gradle和鸿蒙SDK。
3.  确保 `entry/src/main/config.json` 中的 `bundleName` 与Flutter端配置一致。

### 5.2. Platform Channel集成步骤
1.  **Flutter端**: `HarmonyCameraChannel` 类负责向原生层发送指令（如`startCamera`）和接收来自原生层的图像数据流。
2.  **原生端 (ArkTS/Java)**:
    - 在 `entry/src/main/ets/` 中，原生代码会注册一个 `FlutterPlugin`。
    - 此插件监听来自Flutter的调用，并使用鸿蒙的 **Camera Kit** SDK来操作相机。
    - 当相机有新的图像帧可用时，原生代码通过 `EventChannel` 将图像数据（`ByteBuffer`）发送回Flutter。
    - 这个过程实现了Flutter对鸿蒙原生相机能力的调用。

### 5.3. 华为AppGallery发布流程
1.  在DevEco Studio中配置您的应用签名信息。
2.  使用 **Build > Build Hap(s)/APP(s) > Build APP** 生成 `.app` 包。
3.  登录华为AppGallery Connect，创建新应用。
4.  上传 `.app` 包，填写应用信息、截图、隐私声明等。
5.  提交审核。

---

## 6. 性能优化建议

以下建议基于技术研究报告，旨在确保应用流畅运行。

1.  **Isolate并发处理**:
    - 所有的实时图像分析（测光、面部识别）都必须在独立的`Isolate`中完成，以避免阻塞UI主线程。
    - **背压策略**: 为防止处理速度跟不上相机帧率，可以实现一个简单的控制逻辑：当一个Isolate正在处理任务时，暂时不向它发送新的相机帧。
2.  **降低相机分辨率**:
    - 在 `camerawesome` 的配置中，将预览分辨率设置为较低的值（如`720p`），这能极大地降低CPU和内存消耗。
3.  **原生处理优先**:
    - **测光**: 测光算法直接在相机输出的YUV图像格式上进行，其Y通道即为亮度信息，避免了到RGB的昂贵转换。
    - **终极方案**: 如果性能依然不理想，可将整个“图像采集->分析->返回结果”的流程在原生代码（Android/iOS/HarmonyOS）中完成，只将轻量的JSON结果返回给Flutter。
4.  **内存和电池优化**:
    - 确保在退出相机页面时，彻底释放相机资源、停止图像流并关闭Isolate。
    - 避免在UI层进行不必要的重绘。

---

## 7. 测试和调试

### 7.1. 功能测试清单
- [ ] 权限请求：首次启动时是否弹出相机/麦克风权限请求。
- [ ] 相机预览：是否能正常打开前后置摄像头。
- [ ] 测光功能：
  - [ ] 亮度直方图是否实时显示。
  - [ ] 过曝/欠曝区域是否能高亮提示。
  - [ ] 智能建议是否根据画面变化。
- [ ] 面部角度指导：
  - [ ] 能否准确检测到人脸。
  - [ ] 角度提示（文字、箭头）是否实时更新。
  - [ ] “最佳角度”提示是否正常触发。
- [ ] 拍照/录像功能是否正常。

### 7.2. 性能测试方法
- 使用 **Flutter DevTools** 的 Performance 和 Memory 视图，检查UI线程和光栅线程有无卡顿（掉帧），以及内存占用是否稳定。
- 在不同性能的设备（高、中、低端）上进行测试，观察应用的响应速度和发热情况。

---

## 8. 维护和更新

### 8.1. 版本管理
- 推荐使用 **Git Flow** 或类似的流程管理分支，清晰地区分功能开发、版本发布和热修复。
- 每次发布新版本时，都应在Git中打上对应的Tag。

### 8.2. 持续集成 (CI/CD)
- 考虑使用 **Codemagic** 或 **GitHub Actions** 等CI/CD工具。
- 配置自动化流水线，实现代码提交后自动运行测试、构建Android和iOS包，甚至自动发布到TestFlight和Google Play的内部测试轨道。

### 8.3. 用户反馈
- 定期关注App Store和Google Play的用户评论。
- 建立一个简单的渠道（如反馈邮件、社区），用于收集更详细的用户问题和建议。


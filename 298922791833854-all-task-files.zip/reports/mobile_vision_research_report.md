
# 移动端计算机视觉与相机处理技术方案研究报告

**版本**: 1.0
**日期**: 2025年8月7日
**作者**: MiniMax Agent

## 1. 研究目标

本报告旨在为开发一款支持iOS、Android和鸿蒙系统的Flutter跨平台拍照辅助APP，提供全面、前沿且可行的技术方案。研究的核心是解决两大功能需求：**实时测光分析**和**面部角度指导**。

## 2. 核心结论与技术选型总览

| 功能模块 | 推荐技术/插件 | 备选方案 | 关键理由 |
| :--- | :--- | :--- | :--- |
| **相机控制与预览** | `camerawesome` | `camera` (官方插件) | 功能全面，内置UI，对图像流有精细控制，易于实现实时分析。 |
| **图像处理 (测光)** | `opencv_dart` (通过FFI) | `image` 包 | 性能卓越，提供高效的直方图计算等高级CV功能，是实时处理首选。 |
| **面部识别 (角度指导)** | `google_ml_kit` | `tflite_flutter` | API简单，直接提供头部姿态欧拉角，性能优异，完美契合需求。 |
| **权限管理** | `permission_handler` | - | 跨平台标准解决方案，稳定可靠。 |
| **并发处理** | `Isolate` | 原生线程 | Dart标准并发模型，有效防止UI阻塞，满足实时处理需求。 |
| **鸿蒙系统适配** | **Platform Channel + 原生Camera Kit** | FFI + 原生C++ SDK | Flutter官方推荐的与原生通信方式，成熟稳定。 |

---

## 3. Flutter相机和图像处理技术栈

### 3.1. Flutter相机插件选型

**结论：推荐使用 `camerawesome`。**

*   **`camerawesome` ([https://pub.dev/packages/camerawesome](https://pub.dev/packages/camerawesome))**
    *   **优势**:
        1.  **为实时分析优化**: 提供了对相机图像流的直接访问和控制，可以配置分辨率和帧率，这对于性能至关重要。
        2.  **内置可定制UI**: 自带一套完整的相机界面，可大幅缩短开发周期。同时支持完全自定义UI。
        3.  **功能丰富**: 支持闪光灯、变焦、自动对焦、滤镜等常用功能。
        4.  **活跃的社区**: 插件保持更新，社区活跃度高。
    *   **不足**:
        1.  目前官方不支持Web。
        2.  鸿蒙系统需要额外适配。

*   **`camera` (官方插件) ([https://pub.dev/packages/camera](https://pub.dev/packages/camera))**
    *   **优势**:
        1.  **官方维护**: 稳定性和长期支持有保障。Android端已迁移到更现代的`CameraX`库。
        2.  **支持Web**: 平台支持更广泛。
    *   **不足**:
        1.  API相对底层，实现一个功能完善的相机UI需要更多工作。
        2.  对图像流的控制不如`camerawesome`灵活。

### 3.2. Flutter图像处理库对比

**结论：核心实时分析功能推荐使用 `OpenCV`，辅助功能可使用 `image` 包。**

*   **`OpenCV` (通过 `opencv_dart` 或其他FFI插件)**
    *   **优势**:
        1.  **极致性能**: 底层为C++实现，计算密集型任务（如实时计算亮度直方图）性能远超纯Dart实现。
        2.  **功能强大**: 提供了海量的计算机视觉算法，不仅能满足当前需求，也为未来功能扩展（如更复杂的图像分析）打下基础。
    *   **实现方式**: 通过Dart的FFI（Foreign Function Interface）调用原生OpenCV库。需要为iOS, Android分别集成OpenCV SDK。

*   **`image` ([https://pub.dev/packages/image](https://pub.dev/packages/image))**
    *   **优势**:
        1.  **纯Dart实现**: 无需任何原生依赖，集成简单，没有平台兼容性烦恼。
    *   **不足**:
        1.  **性能瓶颈**: 对于来自相机的高帧率实时图像流，进行复杂计算时性能较低，容易导致卡顿。
    *   **适用场景**: 适用于非实时的、简单的图像操作，如对用户选择的单张照片进行裁剪、旋转等。

### 3.3. Flutter实时图像分析性能优化

见第7节“实时性能优化”。

---

## 4. 移动端计算机视觉技术

### 4.1. Google ML Kit vs. TensorFlow Lite

**结论：推荐使用 `Google ML Kit` 实现面部角度指导。**

*   **`Google ML Kit` (通过 `google_ml_kit_face_detection` 插件)**
    *   **优势**:
        1.  **简单高效**: API高度封装，只需几行代码即可实现人脸检测。
        2.  **功能完美匹配**: 其**面部检测**功能可以直接返回人脸的**头部姿态欧拉角 (Head Euler Angle Y/Z)**，这是实现面部角度指导最直接的数据。
        3.  **性能可靠**: Google针对移动端进行了深度优化，性能和功耗表现良好。
    *   **实现**: 使用 `google_mlkit_face_detection` 插件，将相机流的每一帧图像传给`FaceDetector`即可。

*   **`TensorFlow Lite` (通过 `tflite_flutter` 插件)**
    *   **优势**:
        1.  **高度灵活**: 可以加载任何`.tflite`模型，适用于需要自定义模型或实现ML Kit不具备的功能（如人脸身份识别）的场景。
    *   **不足**:
        1.  **复杂度高**: 需要自行处理模型的输入预处理和输出解析。
        2.  **性能依赖模型**: 最终性能取决于所选模型的优劣和优化程度。
    *   **适用场景**: 作为备选方案，当需要实现更高级、更定制化的CV功能时考虑。

---

## 5. 核心算法实现思路

### 5.1. 测光功能实现思路

此功能在`Isolate`中，通过`OpenCV`处理每一帧相机图像。

1.  **获取亮度通道**: 从相机获取YUV格式的图像帧。Y通道即为亮度通道，无需进行RGB到灰度的转换，效率最高。
2.  **计算亮度直方图**:
    *   调用OpenCV的`calcHist`函数，针对Y通道计算一个256个区间的直方图。
    ```cpp
    // OpenCV C++ 伪代码
    cv::Mat yuvImage(height + height/2, width, CV_8UC1, yuv_data);
    cv::Mat luminance;
    cv::extractChannel(yuvImage, luminance, 0); // 提取Y通道
    cv::Mat hist;
    int histSize = 256;
    float range[] = { 0, 256 };
    const float* histRange = { range };
    cv::calcHist(&luminance, 1, 0, cv::Mat(), hist, 1, &histSize, &histRange);
    ```
3.  **分析直方图**:
    *   **平均亮度**: 计算直方图的加权平均值，可作为当前画面的曝光参考值。
    *   **对比度**: 分析直方图的分布范围。分布越广，对比度越高。
    *   **过曝/欠曝检测**:
        *   **过曝**: 检查直方图高光区域（如`hist[250]`到`hist[255]`）的像素总和是否超过阈值。
        *   **欠曝**: 检查直方图暗部区域（如`hist[0]`到`hist[5]`）的像素总和是否超过阈值。
4.  **提供建议**:
    *   **智能建议**: "画面有点暗，请点击暗处提高亮度" 或 "天空过曝，请降低曝光"。
    *   **可视化**: 在UI上绘制实时直方图，并将检测到的过曝/欠曝区域用特定颜色（如红色/蓝色）在预览画面上高亮显示。

### 5.2. 面部角度指导实现思路

此功能在`Isolate`中，通过`ML Kit`处理每一帧。

1.  **获取面部姿态**:
    *   将相机图像帧传递给`ML Kit`的`FaceDetector`。
    *   从返回的`Face`对象中，获取头部欧拉角 `headEulerAngleY` (左右摇头) 和 `headEulerAngleZ` (歪头)。
2.  **定义“最佳角度”**:
    *   **正脸**: `headEulerAngleY` 接近0度 (例如，-10°到+10°)。
    *   **黄金侧脸**: `headEulerAngleY` 接近某个特定角度 (例如，30°或45°，可由用户设置)。
    *   **头部摆正**: `headEulerAngleZ` 接近0度 (例如，-5°到+5°)。
3.  **提供实时反馈**:
    *   **UI提示**: 在屏幕上显示文字，如“请稍微向左转头”、“头部向右歪斜了”。
    *   **图形引导**: 使用箭头或辅助线，动态指示用户如何调整姿态。当达到最佳角度时，可以给出高亮或震动反馈。

---

## 6. 多平台兼容性

### 6.1. 相机权限处理

*   **插件**: 使用`permission_handler`插件。
*   **iOS (`Info.plist`)**:
    ```xml
    <key>NSCameraUsageDescription</key>
    <string>需要访问您的相机以提供拍照和实时分析功能。</string>
    <key>NSMicrophoneUsageDescription</key>
    <string>需要访问您的麦克风以录制视频。</string>
    ```
*   **Android (`AndroidManifest.xml`)**:
    ```xml
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    ```
*   **鸿蒙 (`config.json`)**: 需要在`reqPermissions`中声明相应权限。

### 6.2. 鸿蒙系统适配方案

由于目前没有成熟的、直接支持鸿蒙的Flutter相机插件，需要采用原生集成方案：

1.  **创建Flutter Platform Channel**: 在Flutter端定义一套与原生通信的接口，如`startCamera`, `stopCamera`, `onFrameAvailable`。
2.  **原生鸿蒙实现**:
    *   在鸿蒙模块中，使用华为提供的**Camera Kit** SDK实现相机功能。
    *   监听Platform Channel的调用，并相应地操作原生相机。
    *   获取到相机预览的每一帧数据后，通过Platform Channel的EventChannel将图像数据流式传输回Flutter端。
3.  **数据格式**: 确定一种高效的数据传输格式，可以直接传递图像的字节缓冲区（`ByteBuffer`）。

---

## 7. 实时性能优化

### 7.1. 核心优化策略：Isolate + 降分辨率 + 原生处理

1.  **使用Isolate进行并发处理 (最重要)**:
    *   UI主线程只负责接收相机流和更新UI。
    *   创建一个或多个Worker Isolate，负责所有耗时的图像处理（测光、人脸识别）。
    *   **注意**: 避免在高帧率下Isolate消息队列拥堵。可以设计一种“背压”策略：在Worker Isolate处理完一帧前，主Isolate不再发送新帧，或者每隔几帧发送一次。

2.  **降低相机预览分辨率**:
    *   在`camerawesome`中配置较低的预览分辨率（如`720p`或`480p`）。这能极大减少CPU和内存的负担，是最高效的优化手段。

3.  **直接使用YUV图像格式**:
    *   相机输出的YUV格式图像，其Y通道就是亮度信息。测光算法应直接利用此通道，避免不必要的RGB转换。

4.  **按需处理**:
    *   只有在需要分析的页面才开启图像流处理。退出页面时，务必关闭相机流和Isolate。

5.  **内存管理**:
    *   处理完每一帧图像数据后，确保其相关的内存被及时释放，防止内存泄漏。

6.  **终极方案：原生处理**:
    *   如果上述优化仍不满足性能要求，可将整个处理流程（获取图像帧 -> OpenCV测光 -> ML Kit人脸检测）完全在原生平台（Android/iOS/HarmonyOS）实现。
    *   原生代码只将最终的分析结果（一个轻量的JSON对象）通过Platform Channel返回给Flutter。此方案最大程度地减少了跨语言边界的数据传输，性能最佳，但开发复杂度也最高。

## 8. 总结

本报告提出了一套基于`camerawesome`, `OpenCV`和`Google ML Kit`的综合技术方案。该方案在功能实现、性能表现和跨平台兼容性之间取得了良好平衡。通过采用`Isolate`并发处理、优化图像格式和分辨率，并为鸿蒙系统设计了明确的原生集成路径，可以确保APP在三大主流移动平台上提供流畅、智能的用户体验。建议开发团队以此报告为基础，进行原型开发和性能验证。


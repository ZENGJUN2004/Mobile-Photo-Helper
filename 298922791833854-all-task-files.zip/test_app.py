#!/usr/bin/env python3
"""
Flutter拍照辅助APP代码测试脚本
检查常见的语法问题、依赖问题和配置问题
"""

import os
import re
import json
from pathlib import Path

class FlutterAppTester:
    def __init__(self, app_path):
        self.app_path = Path(app_path)
        self.errors = []
        self.warnings = []
        self.info = []
        
    def log_error(self, message):
        self.errors.append(f"❌ ERROR: {message}")
        
    def log_warning(self, message):
        self.warnings.append(f"⚠️ WARNING: {message}")
        
    def log_info(self, message):
        self.info.append(f"ℹ️ INFO: {message}")
    
    def check_project_structure(self):
        """检查项目结构"""
        print("🔍 检查项目结构...")
        
        required_files = [
            'pubspec.yaml',
            'lib/main.dart',
            'android/app/src/main/AndroidManifest.xml',
            'ios/Runner/Info.plist'
        ]
        
        for file_path in required_files:
            full_path = self.app_path / file_path
            if not full_path.exists():
                self.log_error(f"缺少必需文件: {file_path}")
            else:
                self.log_info(f"找到必需文件: {file_path}")
    
    def check_pubspec_yaml(self):
        """检查pubspec.yaml配置"""
        print("🔍 检查pubspec.yaml配置...")
        
        pubspec_path = self.app_path / 'pubspec.yaml'
        if not pubspec_path.exists():
            self.log_error("pubspec.yaml文件不存在")
            return
            
        try:
            with open(pubspec_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # 检查Flutter SDK版本
            if 'sdk: \'>=3.0.0 <4.0.0\'' in content:
                self.log_info("Flutter SDK版本配置正确")
            else:
                self.log_warning("Flutter SDK版本可能需要更新")
                
            # 检查关键依赖
            required_deps = [
                'camerawesome', 'opencv_dart', 'google_mlkit_face_detection',
                'permission_handler', 'provider'
            ]
            
            for dep in required_deps:
                if dep in content:
                    self.log_info(f"找到依赖: {dep}")
                else:
                    self.log_error(f"缺少依赖: {dep}")
                    
        except Exception as e:
            self.log_error(f"读取pubspec.yaml失败: {e}")
    
    def check_dart_syntax(self):
        """检查Dart代码语法"""
        print("🔍 检查Dart代码语法...")
        
        dart_files = list(self.app_path.glob('lib/**/*.dart'))
        
        for dart_file in dart_files:
            try:
                with open(dart_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检查常见语法问题
                self._check_dart_file_syntax(dart_file, content)
                
            except Exception as e:
                self.log_error(f"读取Dart文件失败 {dart_file}: {e}")
    
    def _check_dart_file_syntax(self, file_path, content):
        """检查单个Dart文件的语法"""
        file_name = file_path.relative_to(self.app_path)
        
        # 检查导入语句
        import_pattern = r'^import\s+[\'"][^\'";]+[\'"];?\s*$'
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 检查导入语句格式
            if line.startswith('import ') and not re.match(import_pattern, line):
                self.log_warning(f"{file_name}:{i} 导入语句格式可能有问题: {line}")
            
            # 检查未结束的字符串
            if line.count("'") % 2 != 0 and not line.endswith('\\'):
                self.log_warning(f"{file_name}:{i} 可能存在未结束的字符串: {line}")
                
            # 检查括号匹配
            open_brackets = line.count('(') + line.count('[') + line.count('{')
            close_brackets = line.count(')') + line.count(']') + line.count('}')
            if abs(open_brackets - close_brackets) > 2:  # 简单检查
                self.log_warning(f"{file_name}:{i} 括号可能不匹配: {line}")
    
    def check_android_config(self):
        """检查Android配置"""
        print("🔍 检查Android配置...")
        
        manifest_path = self.app_path / 'android/app/src/main/AndroidManifest.xml'
        if not manifest_path.exists():
            self.log_error("AndroidManifest.xml文件不存在")
            return
            
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # 检查权限
            required_permissions = [
                'android.permission.CAMERA',
                'android.permission.RECORD_AUDIO'
            ]
            
            for permission in required_permissions:
                if permission in content:
                    self.log_info(f"找到Android权限: {permission}")
                else:
                    self.log_error(f"缺少Android权限: {permission}")
                    
            # 检查相机功能声明
            if 'android.hardware.camera' in content:
                self.log_info("找到相机功能声明")
            else:
                self.log_warning("缺少相机功能声明")
                
        except Exception as e:
            self.log_error(f"读取AndroidManifest.xml失败: {e}")
    
    def check_ios_config(self):
        """检查iOS配置"""
        print("🔍 检查iOS配置...")
        
        info_plist_path = self.app_path / 'ios/Runner/Info.plist'
        if not info_plist_path.exists():
            self.log_error("Info.plist文件不存在")
            return
            
        try:
            with open(info_plist_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # 检查权限描述
            required_permissions = [
                'NSCameraUsageDescription',
                'NSMicrophoneUsageDescription'
            ]
            
            for permission in required_permissions:
                if permission in content:
                    self.log_info(f"找到iOS权限描述: {permission}")
                else:
                    self.log_error(f"缺少iOS权限描述: {permission}")
                    
        except Exception as e:
            self.log_error(f"读取Info.plist失败: {e}")
    
    def check_missing_assets(self):
        """检查缺失的资源文件"""
        print("🔍 检查资源文件...")
        
        pubspec_path = self.app_path / 'pubspec.yaml'
        if pubspec_path.exists():
            try:
                with open(pubspec_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检查assets目录
                if 'assets/images/' in content:
                    assets_dir = self.app_path / 'assets/images'
                    if not assets_dir.exists():
                        self.log_warning("pubspec.yaml中声明了assets/images/，但目录不存在")
                
                if 'assets/icons/' in content:
                    icons_dir = self.app_path / 'assets/icons'
                    if not icons_dir.exists():
                        self.log_warning("pubspec.yaml中声明了assets/icons/，但目录不存在")
                
                # 检查字体文件
                if 'fonts/Roboto-Regular.ttf' in content:
                    font_file = self.app_path / 'fonts/Roboto-Regular.ttf'
                    if not font_file.exists():
                        self.log_warning("pubspec.yaml中声明了字体文件，但文件不存在")
                        
            except Exception as e:
                self.log_error(f"检查资源文件失败: {e}")
    
    def check_provider_usage(self):
        """检查Provider状态管理使用是否正确"""
        print("🔍 检查Provider状态管理...")
        
        main_dart = self.app_path / 'lib/main.dart'
        if main_dart.exists():
            try:
                with open(main_dart, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检查Provider导入
                if 'package:provider/provider.dart' in content:
                    self.log_info("正确导入Provider包")
                else:
                    self.log_error("未导入Provider包")
                
                # 检查MultiProvider使用
                if 'MultiProvider' in content:
                    self.log_info("使用了MultiProvider")
                else:
                    self.log_warning("未使用MultiProvider，可能影响状态管理")
                    
            except Exception as e:
                self.log_error(f"检查Provider使用失败: {e}")
    
    def run_all_tests(self):
        """运行所有测试"""
        print("🚀 开始测试Flutter拍照助手APP...")
        print("=" * 50)
        
        self.check_project_structure()
        self.check_pubspec_yaml()
        self.check_dart_syntax()
        self.check_android_config()
        self.check_ios_config()
        self.check_missing_assets()
        self.check_provider_usage()
        
        # 输出测试结果
        print("\n" + "=" * 50)
        print("📊 测试结果汇总:")
        print("=" * 50)
        
        if self.errors:
            print(f"\n🔴 发现 {len(self.errors)} 个错误:")
            for error in self.errors:
                print(f"  {error}")
        
        if self.warnings:
            print(f"\n🟡 发现 {len(self.warnings)} 个警告:")
            for warning in self.warnings:
                print(f"  {warning}")
                
        if self.info:
            print(f"\n🟢 {len(self.info)} 项检查通过:")
            for info in self.info[:5]:  # 只显示前5个
                print(f"  {info}")
            if len(self.info) > 5:
                print(f"  ... 和其他 {len(self.info) - 5} 项检查")
        
        # 总结
        print(f"\n📈 总览:")
        print(f"  错误: {len(self.errors)}")
        print(f"  警告: {len(self.warnings)}")
        print(f"  通过: {len(self.info)}")
        
        if len(self.errors) == 0:
            print("\n✅ 恭喜！项目没有发现严重错误，可以尝试编译运行。")
        else:
            print(f"\n❌ 发现 {len(self.errors)} 个错误，建议先修复后再编译。")
            
        return len(self.errors) == 0

if __name__ == "__main__":
    app_path = "/workspace/photo_assistant_app"
    tester = FlutterAppTester(app_path)
    success = tester.run_all_tests()
    
    print(f"\n🎯 测试完成，退出代码: {0 if success else 1}")

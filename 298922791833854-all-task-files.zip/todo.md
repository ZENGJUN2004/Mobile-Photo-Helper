# 任务：开发拍照辅助APP

## 目标：创建一个专注于测光和角度指导的原生移动应用

## 步骤：
[✅] 步骤1：研究移动端计算机视觉和相机处理最佳技术方案 -> 研究步骤
[✅] 步骤2：设计并开发完整的Flutter跨平台APP代码（包含测光算法、面部识别、角度指导等核心功能） -> 开发步骤  
[✅] 步骤3：创建详细的iOS、Android和鸿蒙系统部署指南，包括环境配置、编译和发布流程 -> 文档步骤

## 交付物：
1. 完整的Flutter APP源代码
2. 核心功能实现（测光算法、面部识别、角度指导）
3. 详细的iOS、Android和鸿蒙系统部署指南
4. 开发环境配置说明
5. 多平台兼容性说明

## 技术栈：
- 跨平台框架：Flutter（支持iOS、Android、鸿蒙）
- 图像处理：OpenCV for Flutter
- 面部识别：Google ML Kit / Apple Vision Framework
- 相机控制：camera plugin
- 实时图像分析：TensorFlow Lite
- 鸿蒙适配：HarmonyOS Flutter SDK
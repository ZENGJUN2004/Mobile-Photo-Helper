#!/usr/bin/env python3
"""
详细的Flutter APP功能测试
"""

import os
import re
from pathlib import Path

def check_camerawesome_usage():
    """检查CameraAwesome的使用是否正确"""
    print("🔍 检查CameraAwesome使用...")
    
    camera_screen = Path("/workspace/photo_assistant_app/lib/src/screens/camera_screen.dart")
    
    if camera_screen.exists():
        with open(camera_screen, 'r', encoding='utf-8') as f:
            content = f.read()
        
        issues = []
        
        # 检查必要的导入
        if 'package:camerawesome/camerawesome_plugin.dart' not in content:
            issues.append("❌ 缺少CameraAwesome导入")
        else:
            print("✅ CameraAwesome导入正确")
        
        # 检查CameraAwesomeBuilder的使用
        if 'CameraAwesomeBuilder.awesome' in content:
            print("✅ 使用了CameraAwesomeBuilder.awesome")
        else:
            issues.append("❌ 未使用CameraAwesomeBuilder.awesome")
        
        # 检查SaveConfig配置
        if 'SaveConfig.photo' in content:
            print("✅ 配置了照片保存")
        else:
            issues.append("⚠️ 未配置照片保存")
        
        # 检查图像分析配置
        if 'onImageForAnalysis' in content:
            print("✅ 配置了图像分析回调")
        else:
            issues.append("❌ 未配置图像分析回调")
        
        if 'AnalysisConfig' in content:
            print("✅ 配置了分析参数")
        else:
            issues.append("❌ 未配置分析参数")
        
        if issues:
            print("\n发现CameraAwesome使用问题:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ CameraAwesome使用正确")
            
    else:
        print("❌ camera_screen.dart文件不存在")

def check_ml_kit_usage():
    """检查ML Kit使用是否正确"""
    print("\n🔍 检查Google ML Kit使用...")
    
    face_provider = Path("/workspace/photo_assistant_app/lib/src/providers/face_angle_provider.dart")
    
    if face_provider.exists():
        with open(face_provider, 'r', encoding='utf-8') as f:
            content = f.read()
        
        issues = []
        
        # 检查导入
        if 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart' not in content:
            issues.append("❌ 缺少ML Kit面部检测导入")
        else:
            print("✅ ML Kit面部检测导入正确")
        
        # 检查FaceDetector使用
        if 'FaceDetector(' in content:
            print("✅ 正确创建FaceDetector")
        else:
            issues.append("❌ 未正确创建FaceDetector")
        
        # 检查FaceDetectorOptions
        if 'FaceDetectorOptions(' in content:
            print("✅ 配置了FaceDetectorOptions")
        else:
            issues.append("⚠️ 未配置FaceDetectorOptions")
        
        # 检查processImage方法
        if 'processImage(' in content:
            print("✅ 使用了processImage方法")
        else:
            issues.append("❌ 未使用processImage方法")
        
        # 检查头部角度获取
        if 'headEulerAngleY' in content and 'headEulerAngleZ' in content:
            print("✅ 正确获取头部角度")
        else:
            issues.append("❌ 未正确获取头部角度")
        
        if issues:
            print("\n发现ML Kit使用问题:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ ML Kit使用正确")
            
    else:
        print("❌ face_angle_provider.dart文件不存在")

def check_isolate_usage():
    """检查Isolate使用是否正确"""
    print("\n🔍 检查Isolate并发处理...")
    
    light_provider = Path("/workspace/photo_assistant_app/lib/src/providers/light_meter_provider.dart")
    
    if light_provider.exists():
        with open(light_provider, 'r', encoding='utf-8') as f:
            content = f.read()
        
        issues = []
        
        # 检查Isolate导入
        if 'dart:isolate' not in content:
            issues.append("❌ 缺少dart:isolate导入")
        else:
            print("✅ 正确导入dart:isolate")
        
        # 检查Isolate.spawn使用
        if 'Isolate.spawn(' in content:
            print("✅ 使用了Isolate.spawn")
        else:
            issues.append("❌ 未使用Isolate.spawn")
        
        # 检查ReceivePort和SendPort
        if 'ReceivePort(' in content and 'SendPort' in content:
            print("✅ 正确使用ReceivePort和SendPort")
        else:
            issues.append("❌ 未正确使用Port通信")
        
        # 检查Isolate入口函数
        if '_lightMeterIsolateEntry' in content:
            print("✅ 定义了Isolate入口函数")
        else:
            issues.append("❌ 未定义Isolate入口函数")
        
        if issues:
            print("\n发现Isolate使用问题:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ Isolate使用正确")
            
    else:
        print("❌ light_meter_provider.dart文件不存在")

def check_provider_state_management():
    """检查Provider状态管理"""
    print("\n🔍 检查Provider状态管理...")
    
    main_dart = Path("/workspace/photo_assistant_app/lib/main.dart")
    
    if main_dart.exists():
        with open(main_dart, 'r', encoding='utf-8') as f:
            content = f.read()
        
        issues = []
        
        # 检查MultiProvider
        if 'MultiProvider(' in content:
            print("✅ 使用了MultiProvider")
        else:
            issues.append("❌ 未使用MultiProvider")
        
        # 检查ChangeNotifierProvider
        provider_count = content.count('ChangeNotifierProvider(')
        if provider_count >= 3:
            print(f"✅ 注册了{provider_count}个Provider")
        else:
            issues.append(f"⚠️ 只注册了{provider_count}个Provider，预期至少3个")
        
        # 检查Provider类型
        expected_providers = ['CameraProvider', 'LightMeterProvider', 'FaceAngleProvider']
        for provider in expected_providers:
            if provider in content:
                print(f"✅ 注册了{provider}")
            else:
                issues.append(f"❌ 未注册{provider}")
        
        if issues:
            print("\n发现Provider状态管理问题:")
            for issue in issues:
                print(f"  {issue}")
        else:
            print("✅ Provider状态管理正确")
            
    else:
        print("❌ main.dart文件不存在")

def check_permissions():
    """检查权限配置"""
    print("\n🔍 检查权限配置...")
    
    # 检查Android权限
    android_manifest = Path("/workspace/photo_assistant_app/android/app/src/main/AndroidManifest.xml")
    if android_manifest.exists():
        with open(android_manifest, 'r', encoding='utf-8') as f:
            android_content = f.read()
        
        android_permissions = [
            'android.permission.CAMERA',
            'android.permission.RECORD_AUDIO',
            'android.permission.WRITE_EXTERNAL_STORAGE'
        ]
        
        for permission in android_permissions:
            if permission in android_content:
                print(f"✅ Android权限: {permission}")
            else:
                print(f"❌ 缺少Android权限: {permission}")
    else:
        print("❌ AndroidManifest.xml不存在")
    
    # 检查iOS权限
    ios_info_plist = Path("/workspace/photo_assistant_app/ios/Runner/Info.plist")
    if ios_info_plist.exists():
        with open(ios_info_plist, 'r', encoding='utf-8') as f:
            ios_content = f.read()
        
        ios_permissions = [
            'NSCameraUsageDescription',
            'NSMicrophoneUsageDescription',
            'NSPhotoLibraryUsageDescription'
        ]
        
        for permission in ios_permissions:
            if permission in ios_content:
                print(f"✅ iOS权限: {permission}")
            else:
                print(f"❌ 缺少iOS权限: {permission}")
    else:
        print("❌ Info.plist不存在")

def check_ui_widgets():
    """检查UI组件"""
    print("\n🔍 检查UI组件...")
    
    widget_files = [
        "light_meter_overlay.dart",
        "face_angle_overlay.dart", 
        "camera_controls.dart"
    ]
    
    for widget_file in widget_files:
        widget_path = Path(f"/workspace/photo_assistant_app/lib/src/widgets/{widget_file}")
        if widget_path.exists():
            print(f"✅ 存在UI组件: {widget_file}")
            
            # 检查是否正确使用Consumer
            with open(widget_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if 'Consumer<' in content or 'Consumer2<' in content:
                print(f"  ✅ {widget_file} 正确使用Consumer")
            else:
                print(f"  ⚠️ {widget_file} 未使用Consumer")
        else:
            print(f"❌ 缺少UI组件: {widget_file}")

def main():
    print("🚀 开始详细测试Flutter拍照助手APP功能...")
    print("=" * 60)
    
    check_camerawesome_usage()
    check_ml_kit_usage()
    check_isolate_usage()
    check_provider_state_management()
    check_permissions()
    check_ui_widgets()
    
    print("\n" + "=" * 60)
    print("📋 测试建议:")
    print("=" * 60)
    print("1. 在真实设备上测试相机功能")
    print("2. 测试面部检测在不同光线条件下的表现")
    print("3. 验证测光算法的准确性")
    print("4. 检查内存使用和性能表现")
    print("5. 测试多平台兼容性")
    print("\n✅ 详细测试完成！")

if __name__ == "__main__":
    main()
